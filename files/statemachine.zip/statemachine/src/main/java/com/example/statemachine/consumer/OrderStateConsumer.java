package com.example.statemachine.consumer;

import com.example.statemachine.entity.OrderBO;
import org.springframework.messaging.Message;
import org.springframework.statemachine.ExtendedState;
import org.springframework.statemachine.StateContext;
import org.springframework.statemachine.StateMachine;
import org.springframework.statemachine.annotation.*;

import java.util.Map;

/**
 * 状态消费者
 * @author acer01
 */
@WithStateMachine(name = "orderStateMachine")
public class OrderStateConsumer {

    @OnTransition(source = "STATE2",target = "STATE1")
    public void toState1(
                        @EventHeaders Map<String, Object> headers,
                         @EventHeader("myheader1") Object myheader1,
                         @EventHeader(name = "myheader2", required = false) String myheader2,
                         @ExtendedStateVariable("myVar") String myVar,
                         ExtendedState extendedState,
                         StateMachine<String, String> stateMachine,
                         Message<String> message,
                         Exception e,
                         StateContext context) {
        System.out.println("toState1");
    }

    @OnTransition(source = "STATE1",target = "STATE2")
    public void toState2(
                         @EventHeaders Map<String, Object> headers,
                         @EventHeader("myheader1") OrderBO orderBO,
                         @EventHeader(name = "myheader2", required = false) String myheader2,
                         @ExtendedStateVariable("myVar") String myVar,
                         ExtendedState extendedState,
                         StateMachine<String, String> stateMachine,
                         Message<String> message,
                         Exception e,
                         StateContext context) {
        System.out.println("toState2");
    }

    @OnStateChanged(source = "STATE1",target = "STATE2")
    public void onStateChanged(StateContext context){
        System.out.println("onStateChanged");
    }

    @OnStateEntry(source = "STATE1",target = "STATE2")
    public void onStateEntry(StateContext context){
        System.out.println("onStateEntry");
    }

    @OnStateExit(source = "STATE1",target = "STATE2")
    public void onStateExit(StateContext context){
        System.out.println("onStateExit");
    }

    @OnEventNotAccepted(event = {"STATE1","STATE2"})
    public void onEventNotAccepted(StateContext context){
        System.out.println("onEventNotAccepted");
    }

    @OnExtendedStateChanged(key = "STATE1")
    public void onExtendedStateChanged(StateContext context){
        System.out.println("onExtendedStateChanged");
    }

}