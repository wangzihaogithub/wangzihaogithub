package com.example.statemachine.config;

import com.example.statemachine.constant.OrderEventEnum;
import com.example.statemachine.constant.OrderStateEnum;
import org.springframework.context.annotation.Configuration;
import org.springframework.statemachine.config.EnableStateMachine;
import org.springframework.statemachine.config.EnumStateMachineConfigurerAdapter;
import org.springframework.statemachine.config.builders.StateMachineStateConfigurer;
import org.springframework.statemachine.config.builders.StateMachineTransitionConfigurer;

import java.util.EnumSet;

/**
 * @author acer01
 */
public class StateMachineConfig {

    /**
     * 订单状态配置
     */
    @EnableStateMachine(name = "orderStateMachine")
    @Configuration
    public static class OrderStateMachineConfig extends EnumStateMachineConfigurerAdapter<OrderStateEnum, OrderEventEnum> {
        @Override
        public void configure(StateMachineStateConfigurer<OrderStateEnum, OrderEventEnum> states)
                throws Exception {
            states.withStates()
                    .initial(OrderStateEnum.STATE1)
                    .states(EnumSet.allOf(OrderStateEnum.class));
        }

        @Override
        public void configure(StateMachineTransitionConfigurer<OrderStateEnum, OrderEventEnum> transitions)
                throws Exception {
            transitions
                    .withExternal()
                    .source(OrderStateEnum.STATE1).target(OrderStateEnum.STATE2)
                    .event(OrderEventEnum.EVENT1)
                    .and()

                    .withExternal()
                    .source(OrderStateEnum.STATE2).target(OrderStateEnum.STATE1)
                    .event(OrderEventEnum.EVENT2);
        }

   }


}