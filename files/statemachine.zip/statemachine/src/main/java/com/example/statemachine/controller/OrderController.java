package com.example.statemachine.controller;

import com.example.statemachine.constant.OrderEventEnum;
import com.example.statemachine.constant.OrderStateEnum;
import com.example.statemachine.entity.OrderBO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.messaging.Message;
import org.springframework.messaging.support.MessageBuilder;
import org.springframework.statemachine.StateMachine;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.PostConstruct;

@Service
@RestController
@RequestMapping("/order")
public class OrderController {
    @Autowired
    @Qualifier("orderStateMachine")
    private StateMachine<OrderStateEnum, OrderEventEnum> stateMachine;

    @PostConstruct
    public void init() {
        stateMachine.start();
    }

    @Transactional
    @RequestMapping("/create")
    public OrderBO create(Integer skuId) {
        OrderBO orderBO = new OrderBO();
        orderBO.setSkuId(skuId);


        Message<OrderEventEnum> message =
                MessageBuilder.withPayload(OrderEventEnum.EVENT1)
                .setHeader("myheader1",orderBO)
                .setHeader("myHeader2","")
                .build();

        stateMachine.sendEvent(message);

        return orderBO;
    }


}
