package com.example.statemachine.entity;

/**
 * @author acer01
 */
public class OrderBO {
    private Integer skuId;

    public Integer getSkuId() {
        return skuId;
    }

    public void setSkuId(Integer skuId) {
        this.skuId = skuId;
    }
}
