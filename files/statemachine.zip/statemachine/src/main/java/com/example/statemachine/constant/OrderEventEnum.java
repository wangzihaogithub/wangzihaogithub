package com.example.statemachine.constant;

public enum OrderEventEnum {
    EVENT1, EVENT2
}
