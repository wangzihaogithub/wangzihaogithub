package com.example.statemachine.constant;

public enum OrderStateEnum {
    STATE1, STATE2
}
